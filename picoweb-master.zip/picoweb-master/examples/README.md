More picoweb examples
=====================

This directory contains additional examples (beyond a couple available
in the top-level directory) of picoweb usage. These examples are intended
to serve as learn-by-example material, showing various features and
usage patterns of picoweb. Each example starts with a comment header
describe what the example does.

To run these examples, you normally need picoweb already installed (i.e.
available in your MICROPYPATH). If you want a quick start, you need to
try a couple of examples in the top-level dir mentioned above - those
can be run directly from the git checkout.
